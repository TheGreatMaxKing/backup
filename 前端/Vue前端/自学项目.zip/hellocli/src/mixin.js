//混合
export const mixin1={
    data(){
        return{
            //将数据混入其他组件
            mixin1data:"WAWOOO",
            //不会覆盖其他组件已经存在的属性
            price:20,
        }
    },
    methods: {
        showminx(){
            console.log("MIXINFUNC")
        }
    },
    mounted() {
        console.log("MixinMounted")
    },
}