<template>
  <div class="demo">
    <h3>Name:{{name}}</h3>
    <h3>Adress:{{address}}</h3>
    <button @click="showName">ShowName</button>
  </div>
</template>

<script>
export default {
    //规定vue插件中显示的组件名
    name:'School1',
    //组件内的data必须声明为函数式
    data(){
        return{
            name:'UESTC',
            address:'CD'
        }
    },
    methods:{
        showName(){
            alert(this.name)
        }
    }
}
</script>

// 将全局样式变为局部样式
<style scoped>
    .demo{
        border:5px solid blue;
    }
</style>