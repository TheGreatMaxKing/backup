<template>
  <div>
    <h2 ref='Refh2'>REFTEST</h2>
    <ref-son ref='RefComponent'></ref-son>
    <button @click="showRef">ShowRef</button>
  </div>
</template>

<script>
    import RefSon from "./RefSon.vue";

    export default {
    components: { RefSon },
    
    methods:{
        showRef(){
            console.log(this.$refs,this.$refs.Refh2,this)
        }
    }
    };
</script>

<style>
</style>