<template>
    <div>
        <h3>{{name}}{{age}}</h3>
    </div>
</template>

<script>
export default {
    name:'Student',
    data(){
        return{
            name:'max',
            age:18
        }
    }
}
</script>

<style>

</style>