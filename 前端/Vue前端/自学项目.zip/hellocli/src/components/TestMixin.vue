<template>
  <div>
    <hr>
        <div>Mixindata:{{mixin1data}}</div>
        <div>Price:{{price}}</div>
        <button @click="showminx">MixinFunc</button>
    <hr>
  </div>
</template>
    
<script>
    import {mixin1} from '../mixin'

    export default {
        data(){
            return{
                price:100
            }
        },
        mixins:[mixin1],
        mounted(){
            console.log("MMMmounted")
        }
    }
</script>

<style>

</style>