<template>
  <div>
    <input type="text" v-focus v-model="name">
    <div>插件全局混入属性 {{globalmixinData}}</div>
    <div>插件定义管道 {{testpipe|myfilter}}</div>
    <button @click="myPrototypeFunc">插件原型方法</button>
  </div>
</template>

<script>
    export default {
        data(){
            return{
                testpipe:"1234567",
                name:"插件定义的聚焦指令"
            }
        },
        mounted(){
          console.log("CCC",this.$bus)
        }
    }
</script>

<style>

</style>