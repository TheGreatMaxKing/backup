<template>
    <div>
        <hr/>
        <h3>名称：{{carName}}</h3>
        <div>速度：{{accelerateSpeed}}</div>
        <button @click="speedUp">加速</button>
        <hr/>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                //不能直接更改props内的值，但可以将其传给data内的属性
                accelerateSpeed:this.originSpeed
            }
        },
        methods:{
            speedUp(){
                this.accelerateSpeed=this.accelerateSpeed+1
            }
        },

        //props配置1
        // props:['carName','originSpeed'],

        //prosp配置2
        // props:{
        //     carName:String,
        //     originSpeed:Number,
        // }

        //props配置3
        props:{
            carName:{
                type:String,
                required:true,
            },
            originSpeed:{
                type:Number,
                default:40,
            }
        }
    }
</script>

<style>

</style>