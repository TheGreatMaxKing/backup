<template>
  <div>
    <div>name:SPACEX</div>
    <div>一级燃料:{{fuel1}} 剩余空间{{fuel1space}}</div>
    <div>二级燃料:{{FuelModule.fuel2}}</div>
    <div>三级燃料:{{this.$store.state.FuelModule.fuel3}}</div>
  </div>
</template>

<script>
import {mapState,mapGetters,mapActions,mapMutations} from 'vuex'

export default {
  data(){
    return{

    }
  },
  computed:{
    //模块化state写法1,需要将模块中的namespaced属性设为true
    ...mapState('FuelModule',['fuel1','fuel2','fuel3']),

    //写法2 ： {{FuelModule.fuel1}}
    ...mapState(['FuelModule']),

    ...mapGetters('FuelModule',['fuel1space'])
  }
}
</script>

<style>

</style>