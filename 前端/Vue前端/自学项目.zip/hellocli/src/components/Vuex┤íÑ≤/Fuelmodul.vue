<template>
  <div>
    <button v-focus @click="addFuel1(2)">添加一级燃料</button>
  </div>
</template>

<script>
import { mapMutations,mapActions } from 'vuex'
    export default {
      data(){
        return{

        }
      },
      methods:{
        ...mapActions('FuelModule',{'addFuel1':'addFuel1'})
      },
      mounted(){
        console.log(this.$store)
      }
    }
</script>

<style>

</style>