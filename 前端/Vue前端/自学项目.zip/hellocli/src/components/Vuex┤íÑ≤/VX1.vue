<template>
  <div>
    <h1>{{name}}{{level}}当前和为:{{count}},{{$store.state.sum}}</h1>
    <h2>getters数据{{$store.getters.bigSum}},{{doubleSum}},{{trebleSum}}</h2>
    <select v-model.number="n">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
    </select>
    <button @click="add">+</button>
    <button @click="subtract(n)">-</button>
    <button @click="addOdd">当前求和为奇数再加</button>
    <button @click="addWait">等一等再加</button>
  </div>
</template>

<script>
    import {mapState,mapGetters,mapActions,mapMutations} from 'vuex'

    export default {
        data(){
           return{
            n:1,
            //测试 不可将Vuex转为data
            count:this.$store.state.sum
           }
        },
        computed:{
            // ////Vuex state转计算属性方法一
            // name(){
            //     return this.$store.state.name
            // },
            // level(){
            //     return this.$store.state.level
            // }
            // ////

            // 
            // Vuex mapstate 写法1
            // ...mapState({name:'name',level:'level'})
            // 

            // Vuex mapstate 简写
            ...mapState(['name','level']),

            //Vuex mapgetters
            ...mapGetters(['doubleSum','trebleSum'])

        },
        methods:{
            add(){
                this.$store.dispatch('add',this.n)
            },
            // subtract(){
            //     //直接commit略过action步骤
            //     this.$store.commit('SUBTRACT',this.n)
            // },

            //靠mapMutations生产函数
            //!!!必须在模板绑定事件时传入参数，否则会默认传入$event
            ...mapMutations({'subtract':'SUBTRACT'}),

            addOdd(){
                this.$store.dispatch('addOdd',this.n)
            },
            addWait(){
                this.$store.dispatch('addWait',this.n)
            }
        }
    }
</script>

<style>

</style>