<template>
  <div>
    <button @click="changeList">操作数组</button>
    数组{{list[0]}}-----{{list[1]["id"]}}----{{list[1]["score"]}}
    <button @click="changeList2">操作数组内的对象</button>
    {{list[1]["score"]}}
    <button @click="addList">添加数组对象</button>{{list}}
  </div>
</template>

<script>
export default {
    data(){
        return{
            list:[1,{
                "name":"KEN",
                id:10
            }]
        }
    },
    methods:{
        changeList(){
            this.list[0]=this.list[0]+1;
            this.list[1]["id"]=this.list[1]["id"]+1
            this.list[1]["score"]=100
            this.$set(this.list,1,{...this.list[1],"score":100})
            console.log("数组",this)
        },
        changeList2(){
             this.list[1]["score"]=this.list[1]["score"]+1;
        },
        addList(){
            this.list.push(1)
        }
    }
}
</script>

<style>

</style>