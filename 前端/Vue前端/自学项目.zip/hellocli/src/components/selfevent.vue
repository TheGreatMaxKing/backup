// 子传父的两张方式
<template>
    <div>
        <div>event</div>
        <button @click="getSonByFunc(sonName1)">通过父组件函数实现子传父</button>
        <br>
        <button @click="selfEventOn">通过自定义事件实现子传父</button>
        <br>
        <button @click="selfRefEventOn">通过ref绑定的自定义事件</button>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                sonName1:"Func",
                sonName2:"自定义事件",
                sonName3:'通过ref绑定的自定义事件'
            }
        },
        props:['getSonByFunc'],
        methods:{
            selfEventOn(){
                //触发自定义事件  事件名     传入参数
                this.$emit('selfEventFunc',this.sonName2)
            },
            selfRefEventOn(){
                this.$emit('selfeventMount',this.sonName3,this.sonName1,this.sonName2)
            }
        }
    }
</script>

<style>

</style>