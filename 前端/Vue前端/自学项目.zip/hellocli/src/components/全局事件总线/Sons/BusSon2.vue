<template>
  <div>
    BusSon2
    <br>
    <button @click="sendToSon1">向SON1传值</button>
  </div>
</template>

<script>
export default {
    data(){
        return{
            Son2Name:"Son2"
        }
    },
    methods:{
        sendToSon1(){
            this.$bus.$emit('SON1Event',this.Son2Name)
        }
    }
}
</script>

<style>

</style>