<template>
  <div>
    BusSon1
    <div>从SON2接收数据:{{Son1Name}}</div>
  </div>
</template>

<script>
export default {
    data(){
        return{
            Son1Name:"SON1"
        }
    },
    mounted(){
        //通过全局事件总线直接挂载自定义事件实现任意组件间通信
        //设定事件时若采用直写匿名函数的方式需要使用箭头函数
        this.$bus.$on('SON1Event',(data)=>{
            this.Son1Name=data
            console.log("SON1接收到数据",data)
        })
    },
    beforeDestroy(){
        //组件销毁时解绑其上定义的自定义事件
        this.$bus.$off('SON1Event')
    }
}
</script>

<style>

</style>