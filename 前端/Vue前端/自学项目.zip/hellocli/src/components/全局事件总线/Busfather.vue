<template>
  <div>
    BusF
    <hr>
    <BusSon1/>
    <hr>
    <BusSon2/>
  </div>
</template>

<script>
    import BusSon1 from './Sons/BusSon1.vue'
    import BusSon2 from './Sons/BusSon2.vue'
    export default {
        components:{
            BusSon1,
            BusSon2
        }
    }
</script>

<style>

</style>