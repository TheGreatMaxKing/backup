<template>
  <div id="app">
    <manipulate-arry></manipulate-arry>
    <SchoolHHH></SchoolHHH>
    <Student></Student>
    <hr>
    <ref-test/>
    <hr>
                                  <!-- 使用v-bind传入数字 -->
    <test-props carName="捞丝莱丝" :originSpeed="120"/>
    <test-props carName="比亚迪"  />
    <hr>
    <test-mixin/>
    <hr>
    <hr>
    <test-plugin/>
    <hr>
    <hr>
    父组件接收：{{msg}}
    <self-event ref='selfeventref' :getSonByFunc='getSonByFunc' v-on:selfEventFunc='selfEventFunc'/>
    <hr>
    <hr>
    <bus-father/>
    <hr>
    <hr>
    <VX1/>
    <hr>
    <hr>
    <h2>NASA</h2>

      <rocket/>
      <hr>
      <fuel/>

  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import SchoolHHH from './components/School.vue'
import Student from './components/Student.vue'
import RefTest from './components/RefTest/RefTest.vue'
import TestProps from './components/TestProps.vue'
import TestMixin from './components/TestMixin.vue'
import TestPlugin from './components/TestPlugin.vue'
import SelfEvent from './components/selfevent.vue'
import BusFather from './components/全局事件总线/Busfather.vue'
import VX1 from './components/Vuex插件/VX1.vue'
import Fuel from './components/Vuex插件/Fuelmodul.vue'
import Rocket from './components/Vuex插件/Rocketmodul.vue'
import manipulateArry from './components/数组.vue'


export default {
  name: 'App',
  components: {
    // HelloWorld,
    SchoolHHH,
    Student,
    RefTest,
    TestProps,
    TestMixin,
    TestPlugin,
    SelfEvent,
    BusFather,
    VX1,
    Fuel,
    Rocket,
    manipulateArry
  },
  data(){
    return{
      msg:'Father'
    }
  },
  methods:{
    getSonByFunc(name){
      this.msg=name
      console.log('App通过函数收到子组件Name',name)
    },
    selfEventFunc(name){
      this.msg=name
      console.log('自定义事件被触发了')
    },
    //传入多个参数
    selfEventFuncMount(name,...a){
      this.msg=name
      console.log('通过ref和mounted绑定的自定义事件被触发了',a)
    }
  },
  mounted(){
    //通过mounted和ref绑定自定义事件功能更强大
    setTimeout(()=>{
      this.$refs.selfeventref.$on('selfeventMount',this.selfEventFuncMount)
    },3000)
    console.log("VC",this)
    console.log("ENV",process.env)
  }

}
</script>

<style>
/* #app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} */
</style>
