//插件，用于增强Vue功能
export default{
    //传入Vue对象
    install(Vue){
        console.log("Install")
        //全局过滤器
        Vue.filter('myfilter',function(value){
            return value.slice(0,4)
        })

        //全局指令
        Vue.directive('focus', {
            // 当被绑定的元素插入到 DOM 中时……
            inserted: function (el) {
              // 聚焦元素
              el.focus()
            }
          })

        // Vue.directive('fbind',{
        //     //指令与元素绑定成功是
        //     bind(element,binding){
        //         element.value=binding.value
        //         binding.value=element.value
        //         // element.focus()
        //         console.log("bind",element,binding)
        //     },

        //     //指令元素被插入页面时
        //     inserted(element,binding){
        //         element.focus()
                
        //         console.log("Inserted",element,binding)
        //     },

        //     //指令所在模板被重新解析时调用
        //     update(element,binding){
        //         element.value=binding.value
           
        //         console.log("update",element,binding)
        //     }
        // })

        
        
        //全局混入
        Vue.mixin({
            data(){
                return {
                    globalmixinData:"GMixin"
                }
            }
        })

        //Vue原型添加方法
        Vue.prototype.myPrototypeFunc=()=>{
            console.log("myPrototypeFunc",Vue)
        }
    }

}