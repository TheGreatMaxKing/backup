//自定义模块
const FuelModule={
    namespaced:true,
    state:{
      fuel1:0,
      maxfuel1:10,
      fuel2:0,
      maxfuel2:20,  
      fuel3:0,
      maxfuel3:30,    
    },
    actions:{
      addFuel1(context,value){
        let fuel1=context.state.fuel1
        let maxfuel1=context.state.maxfuel1
        if(fuel1<maxfuel1){
            console.log("FFFF",value)
            if(fuel1+value<=maxfuel1){
                context.commit('ADDFUEL1',value)
            }
            else{
                context.commit('ADDFUEL1',maxfuel1-fuel1)
            }
        }
      }  
    },
    mutations:{
        ADDFUEL1(state,value){
            console.log("AF",value)
            state.fuel1+=value
        }
    },
    getters:{
        fuel1space(state){
            return state.maxfuel1-state.fuel1
        }
    }

}

export default FuelModule