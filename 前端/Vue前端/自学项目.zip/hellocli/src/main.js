// 整个项目的入口文件

//引入Vue
import Vue from 'vue'
//引入App组件,所有组件的父组件
import App from './App.vue'
//引入插件
import plugins from './plugins'

//引入Vuex
import Vuex from 'vuex'
//引入Vuex的store
import store from './store/index'


//关闭vue提示
Vue.config.productionTip = false

//应用插件
Vue.use(plugins)


//创建唯一Vue实例
new Vue({
  render: h => h(App),

  store,

  /////!!!!!!!!!安装全局事件总线
  beforeCreate(){
    Vue.prototype.$bus=this
    console.log("VM",this)
  }
}).$mount('#app')//在index.html中挂载app
