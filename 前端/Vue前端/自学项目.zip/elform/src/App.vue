<template>
  <div id="app">
    <normalform></normalform>
  </div>
</template>

<script>
import normalform from './components/normalform.vue'

export default {
  name: 'App',
  components: {
    normalform
  }
}
</script>

<style>

</style>
