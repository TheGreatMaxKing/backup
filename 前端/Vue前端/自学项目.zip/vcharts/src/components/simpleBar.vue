<template>
  <div ref="simpleBar"></div>
</template>

<script>
// import * as echarts from "echarts";
export default {
  mounted() {
    let myEcharts = this.$echarts.init(this.$refs.simpleBar);
    //设置参数
    myEcharts.setOption({
      title: {
        text: "柱状图",
      },
      xAxis: {
        data: ["EZ", "VN", "NOC", "MF"],
      },
      yAxis: {},
      series: {
        name: "Test",
        type: "bar",
        data: [100, 80, 20, 60],
      },
    });
    window.onresize = function () {
      myEcharts.resize();
    };
  },
};
</script>

<style>
</style>