<template>
  <div ref="simplePie"></div>
</template>

<script>
export default {
  mounted() {
    let linechart = this.$echarts.init(this.$refs.simplePie);
    linechart.setOption({
      title: {
        text: "饼图",
      },
      series: [
        {
          type: "pie",
          //   radius: '70%',
          data: [
            {
              value: 335,
              name: "PMIS",
            },
            {
              value: 234,
              name: "OHRP",
            },
            {
              value: 154,
              name: "Admin",
            },
          ],
        },
      ],
    });

    let sizeFun = function () {
      linechart.resize();
    };
    window.addEventListener("resize", sizeFun);
  },
};
</script>

<style>
</style>