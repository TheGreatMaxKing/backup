<template>
  <div style="">
    <div id="test" ref="simpleScatter" class="testchangeson" style="width:100%!important;height:100%!important"></div>
    <!-- <canvas  style="background:red;width:100%;height:100%"></canvas> -->
  </div>
</template>

<script>
export default {
  mounted() {
    let linechart = this.$echarts.init(this.$refs.simpleScatter);
    linechart.setOption({
      title: {
        text: "散点图",
      },
      xAxis: {
        data: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      },
      //   grid: {
      //   //图标离容器的距离
      //   left: "2%",
      //   right: "2%",
      //   top: "5%",
      //   bottom: "1%",
      // },
      yAxis: {},
      series: [
        {
          type: "scatter",
          data: [100, 12, 11, 24, 490, 130, 210],
        },
      ],
    });
    // this.$nextTick(()=>{
    //   console.log('NEXT')
    //   linechart.resize()
    // })
    //  window.onresize = function () {
    //   linechart.resize();
    // };

    // document.getElementsByTagName('canvas')[3].width=window.innerWidth;
    // document.getElementsByTagName('canvas')[3].height=window.innerHeight;
    console.log('EEE',document.getElementsByTagName('canvas')[3].width,document.getElementsByTagName('canvas')[3].height,document.getElementById("test").clientWidth,document.getElementById("test").clientHeight)
    console.log("RRR",this.$refs,this.$refs.simpleScatter,this.$refs.$el)
  },
};
</script>

<style>
  .testchangeson *{
    width: 100%!important;
    height: 100%!important;
  }

  canvas {
    width: 100%!important;
    height: 100%!important;
  }
</style>