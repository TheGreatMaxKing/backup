<template>
  <div id="simpleLinediv">
    <div ref="simpleLine"  style="width:100%;height:100%"></div>
  </div>
</template>

<script>
import {EleResize} from '../assets/js/esresize.js'
export default {
  mounted() {
    let simpleLinediv=document.getElementById("simpleLinediv")

    let linechart = this.$echarts.init(this.$refs.simpleLine);
    linechart.setOption({
      title: {
        text: "折线图",
      },
      xAxis: {
        type: "category",
        data: ["1月", "2月", "3月", "4月", "5月", "6月"],
      },
      // grid: {
      //   //图标离容器的距离
      //   left: "1%",
      //   right: "2%",
      //   top: "10%",
      //   bottom: "13%",
      // },
      yAxis: {
        type: "value",
      },
      series: [
        {
          data: [120, 200, 150, 200, 220, 300],
          type: "line",
        },
      ],
    });

    console.log(EleResize)
    let listener=function(){
      linechart.resize()
    }

    EleResize.on(simpleLinediv,listener)
  },
};
</script>

<style>
</style>