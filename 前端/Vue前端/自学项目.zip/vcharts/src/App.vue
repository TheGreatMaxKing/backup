<template>
<div>
  <div class="flexdisplayrow" >
    <simple-bar></simple-bar>
    <simple-line></simple-line>
    <simple-pie></simple-pie>
    <simple-scatter></simple-scatter>
  </div>
</div>
</template>

<script>
import simpleBar from './components/simpleBar.vue'
import SimpleLine from './components/simpleLine.vue';
import SimplePie from './components/simplePie.vue'
import simpleScatter from './components/simpleScatter.vue'

export default {
  name: "App",
  components:{
    simpleBar,
    SimpleLine,
    SimplePie,
    simpleScatter
  }
};
</script>
 
<style>

.flexdisplayrow {
  display: flex;
  /* 设置主轴 */
  flex-direction: row;

  /* 设置主轴对齐方式 */
  justify-content:  flex-start ;

  /* 设置交叉轴对齐方式 */
  align-items: center;

  height: 350px;

  width: 100%;
  border: 1px solid red;
}

.flexdisplayrow > * {
  width: 24%;
  height: 90%;
  border: 1px solid blue;
  box-sizing: border-box;
  margin-left:1%;
  margin-right: 1%;
}
</style>
