<template>
  <div id="app">
    <td>
      <div>
        <div class="rdiv">
          <router-link class="rlink" active-class="rlink-active" to="/hello"
            >MAIN</router-link
          >
        </div>
        <div>
          <router-link class="rlink" active-class="rlink-active" to="/catchable"
            >路由缓存</router-link
          >
        </div>
      </div>
    </td>
    <td>
      <div style="margin-left: 20px">
        <!-- ！！！路由缓存 -->
        <!-- 声明要缓存的组件名！！！！ -->
        <keep-alive :include="['RouterCatch']">
          <router-view></router-view>
        </keep-alive>
      </div>
    </td>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
};
</script>

<style>
.rlink {
  border: 2px solid black;
  border-radius: 3px;
}
.rdiv {
  margin: 10px 0 10px 0;
}
.rlink-active {
  background-color: rgba(15, 66, 128, 0.5);
}
</style>
