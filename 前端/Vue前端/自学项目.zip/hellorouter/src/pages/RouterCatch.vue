<template>
  <div>
    可缓存路由页面
    <input type="text"/>
    <input type="text"/>
    <br>
    <div :style="{opacity}">路由生命周期</div>
  </div>
</template>

<script>
export default {
    name:'RouterCatch',
    data(){
      return{
        opacity:1
      }
    },
    //路由组件激活时调用
    //当设置缓存路由组件后，路由被切走时不会destroy
    activated(){
      console.log("生命周期Activated")
      this.timer=setInterval(()=>{
        this.opacity-=0.01
        if(this.opacity<=0){
          this.opacity=1
        }
      },10)
    },

    //路由组件切出时调用
    deactivated(){
      console.log("生命周期Deactivated")
      clearInterval(this.timer)
    },

    beforeCreate(){
      console.log("生命周期BeforeCreate")
    },

    beforeDestroy(){
      console.log("生命周期BeforeDestroy")
    }


}
</script>

<style>

</style>