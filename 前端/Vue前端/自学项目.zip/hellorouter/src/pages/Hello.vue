<template>
  <div>
    MAIN
    <div>
                                        <!-- replace属性 -->
    <router-link style="margin:10px 10px 0 0" replace to='/hello/son1'>SON1</router-link>
    <router-link style="margin:10px 10px 0 0" :replace='true' to='/hello/routeProps'>routeProps</router-link>
    <!-- <input type="text"> -->
    <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>