<template>
  <div>
    <div>routeProps</div>
    <div>
      <ul>
        <li v-for="e in list" :key="e.name">
          <!-- 路由传参params写法1 -->
          <!-- <router-link :to='`/hello/routeProps/routepropsson/${e.id}/${e.name}`'>{{e.name}}</router-link> -->

          <!-- 路由传参params写法2 to 传参-->
          <!--!!!!!!!不允许写path ，只能写name-->
          <router-link
            :to="{
              //path: '/hello/routeProps/routepropsson',
              name:'routepropsson',
              params: {
                id: e.id,
                name: e.name,
              },
              query:{
                pqname:'PPP'+e.name
              }
            }"
          >
            {{ e.name }}
          </router-link>
        </li>
      </ul>
    </div>
    <hr />
    <div>
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
    data(){
        return{
            list:[
                {id:1,name:"P1"},
                {id:2,name:"P2"},
                {id:3,name:"P3"}
                ]
        }
    }
};
</script>

<style>
</style>