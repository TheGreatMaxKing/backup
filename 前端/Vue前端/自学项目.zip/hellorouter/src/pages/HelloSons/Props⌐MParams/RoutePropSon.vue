<template>
  <div>
    <h3>PropsSon</h3>
    <h4>常规接收参数</h4>
    <div>ID:{{$route.params.id}}</div>
    <div>NAME:{{$route.params.name}}</div>
    <div>Query参数{{$route.query.pqname}}</div>
    <!-- <h4>Props接收参数方法1</h4>
    <div>PID1:{{a}}</div>
    <div>PName1:{{b}}</div> -->

    <h4>Props接收参数方法2</h4>
    <div>PID2:{{id}}</div>
    <div>PName2:{{name}}</div>
    <div>Query参数{{pqname}}</div>
  </div>
</template>

<script>
    export default {
        //props写法1
        //props:['a','b'],

        //props写法2
        props:['id','name','pqname'],
        mounted(){
            console.log(this.$route)
        }
    }
</script>

<style>

</style>