<template>
  <div>
    <h4>SG{{this.$route.query.id}}</h4>
    <div>ID:{{this.$route.query.id}}</div>
    <div>NAME:{{this.$route.query.name}}</div>
    <input type="text"/>
  </div>
</template>

<script>
export default {
    mounted(){
        console.log("组件上的路由",this.$route)
    }
}
</script>

<style>

</style>