<template>
  <div>
    <div>Son1</div>
    <div>
        <ul>
            <li v-for="e in list" :key="e.name">
                <!-- 路由传参写法1 -->
                <!-- <router-link :to='`/hello/son1/son1g?id=${e.id}&name=${e.name}`'>{{e.name}}</router-link> -->
                
                <!-- 路由传参写法2 to 传参-->
                <router-link :to="{
                    path:'/hello/son1/son1g',
                    query:{
                        id:e.id,
                        name:e.name
                    }
                }">
                {{e.name}}
                <button @click="pushShow(e)">push函数跳转</button>
                <button @click="replaceShow(e)">replace函数跳转</button>
                </router-link>
            </li>
        </ul>
    </div>
    <hr>
    <div>
        <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
    data(){
        return{
            list:[
                {id:1,name:"G1"},
                {id:2,name:"G2"},
                {id:3,name:"G3"}
                ]
        }
    },
    methods:{
        pushShow(e){
            console.log("Router",this.$router)
            this.$router.push({
                path:'/hello/son1/son1g',
                    query:{
                        id:e.id,
                        name:e.name
                    }
            })
        },
        replaceShow(e){
            this.$router.replace({
                path:'/hello/son1/son1g',
                    query:{
                        id:e.id,
                        name:e.name
                    }
            })
        }
    }
}
</script>

<style>

</style>