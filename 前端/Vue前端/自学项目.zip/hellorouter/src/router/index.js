//路由配置文件
import VueRouter from 'vue-router'

//引入组件
import Catchable from '../pages/RouterCatch'
import Hello from '../pages/Hello'
import HelloSon1 from '../pages/HelloSons/push和replace/HelloSon1'
import Son1G from '../pages/HelloSons/push和replace/Son1G'

import RouteProps from '../pages/HelloSons/Props和Params/RouteProps'
import RoutePropSon from '../pages/HelloSons/Props和Params/RoutePropSon'

//解决报错
//#region
/////解决报错
///使用$router.push和replace函数时报错
///https://blog.csdn.net/m0_46615524/article/details/125898988
///Uncaught (in promise) NavigationDuplicated: Avoided redundant navigation to current location: 
const originalPush = VueRouter.prototype.push
const originReplace=VueRouter.prototype.replace;

//重写push/replace
//第一个参数：告诉原来的push方法，往哪里跳转（传递哪些参数）
//第二个参数：成功的回调
//第三个参数：失败的回调
//call/apply区别
//相同点：都可以调用函数一次，都可以篡改函数的上下文(this）一次‘
//不同点：call/apply传递参数：call传递参数用逗号隔开，apply方法执行，传递数组

VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

VueRouter.prototype.replace=function(location,resolve,reject){
    if(resolve&&reject){
        originReplace.call(this,location,resolve,reject);
    }else{
        originReplace.call(this,location,()=>{},()=>{});
    }
}
///解决完成

//创建路由器
//#endregion

const routes=new VueRouter({

    //设置为history模式 默认为hash 详见尚硅谷133
    // mode:'history',

    routes:[
        {
            path:'/catchable',
            component:Catchable,

            //自定义的路由参数添加位置，可以用于权限验证
            meta:{
                isAuth:true
            },

            //独享路由守卫 只有前置没有后置
            beforeEnter(to ,from ,next){
                console.log("独享路由守卫",to,from,next)
                next()
            }
        },
        {
            path:'/hello',
            component:Hello,
            children:[
                {
                    //!!!!!不加'/'
                    path:'son1',
                    name:'pushandreplace',
                    component:HelloSon1,
                    children:[
                        {
                            path:"son1g",
                            component:Son1G
                        }
                    ]
                },
                {
                    //!!!!!不加'/'
                    path:'routeProps',
                    name:'RouteProps',
                    component:RouteProps,
                    children:[
                        {
                            name:'routepropsson',
                            path:'routepropsson/:id/:name',
                            component:RoutePropSon,

                            //props写法1,该对象的所有key-value都会以props的形式传给组件（不推荐）
                            // props:{a:1,b:'hello'}

                            //props写法2，将所有收到的！！！params参数（不是Query参数）传给组件
                            // props:true

                            // props写法3 可以传递query参数
                            props($route){
                                return{
                                    id:$route.params.id,
                                    name:$route.params.name,
                                    pqname:$route.query.pqname
                                }
                            }
                        }
                    ]
                }
            ]
        }
    ]
})

//!!!!全局前置路由守卫————初始化及每次路由切换时调用
routes.beforeEach((to,from,next)=>{
    console.log("Guard",to,from,next)
    //权限控制to.path ,.name ,.meta
    if(to.meta.isAuth===true||to.path==='/hello'||to.name==='pushandreplace'||to.name==='RouteProps'){
        if(!localStorage.getItem('MaxOnly')){
            next()
        }else{
            alert("YOU ARE NOT MAX")
        }
    }
    else{
        next()
    }
})

//全局后置路由
routes.afterEach((to,from)=>{
    console.log("后置路由",to,from)
    document.title=to.meta.title||'HHHH'
})

export default routes