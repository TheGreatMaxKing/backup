<template>
  <div>
    <!-- 函数实现子传父 -->
    <!-- <ListHeader :addOneTask="addOneTask"/> -->
    <!-- 自定义事件实现子传父 -->
    <ListHeader @addOneTaskEvent="addOneTask"/>
    <list :todolist='todolist' :checkTask='checkTask' :deleteTask='deleteTask'></list>
     <!-- 函数实现子传父 -->
    <!-- <ListHeader :addOneTask="addOneTask"/> -->
    <!-- 自定义事件实现子传父 -->
    <bottom :todolist='todolist' :checkAll='checkAll' :deleteAllCompleted='deleteAllCompleted'></bottom>
  </div>
</template>

<script>
  import ListHeader from './components/ListHeader.vue'
  import Bottom from './components/Bottom.vue'
  import List from './components/List.vue'

  export default {
    name: 'App',
    components: {
      ListHeader,
      Bottom,
      List,
    },
    data(){
      return{
        todolist:JSON.parse(localStorage.getItem('todolist'))||[]
      }
    },

    methods:{
      //子组件修改父组件属性的方法，将父组件的函数传给子组件
      addOneTask(task){
        this.todolist.unshift(task)
      },

      //勾选
      checkTask(id){
        this.todolist.forEach((e)=>{
          if(e.id==id){
            e.completed=!e.completed
          }
        })
      },

      //删除
      deleteTask(id){
        this.todolist=this.todolist.filter((e)=>{
          return e.id!==id
        })
      },

      //全选
      checkAll(checked){
        this.todolist.map((e)=>{
          e.completed=checked
        })
        console.log("Data todolist",this.todolist)
      },

      //清除已完成
      deleteAllCompleted(){
        this.todolist=this.todolist.filter((e)=>{
          return e.completed==false
        })
      },

      //编辑任务
      editTask(id,newTaskName){
        //！！！ 错误写法！！！不能直接通过id操作data数组
        // ！！！this.todolist[id].name=newTaskName
        this.todolist.forEach((e)=>{
          if(e.id==id){
            e.name=newTaskName
          }
        })
      }
    },

    //watch实现浏览器缓存
    watch:{
      todolist:{
        deep:true,
        handler(value){
          localStorage.setItem('todolist',JSON.stringify(value))
        }
      }
    },

    mounted(){
      //绑定全局自定义事件
      this.$bus.$on('checkTaskEvent',this.checkTask)
      this.$bus.$on('deleteTaskEvent',this.deleteTask)
      this.$bus.$on('editTaskEvent',this.editTask)
    },

    beforeDestroy(){
      //组件销毁时解绑其自定义事件
      this.$bus.$off(['checkTaskEvent','deleteTaskEvent','editTaskEvent'])
    }
  }
</script>

<style>

</style>
