<template>
  <div style="margin:5px 0 10px 0">
    <!-- 写法一 -->
    <!-- 通过浅拷贝的方式直接修改props传入对象的属性,不推荐写法 -->
    <!-- <input type="checkbox" v-model="task.completed"/> -->
    <!-- {{task.name}} -->
    <!-- <button @click="taskDelete(task.id)">删除</button> -->
     <!-- 写法一完 -->
   
    <!-- 写法二 -->
                                                      <!-- 也可以用click -->
    <!-- <input type="checkbox" :checked="task.completed" @change="taskCheck(task.id)"/> -->
    <!-- {{task.name}} -->
    <!-- <button @click="taskDelete(task.id)">删除</button> -->
    <!-- 写法二完 -->

    <!-- 写法三 全局事件组件实现孙传祖-->
    <input type="checkbox" :checked="task.completed" @change="taskCheckEvent(task.id)"/>
    <span v-show="!isShowEdit">{{task.name}}</span>
    <span v-show="isShowEdit"><input type="text" v-model="editvalue" ref="editinput" @keyup.enter="commitEdit(task.id,editvalue)"></span>
    <button :style="{margin:'0 2px 0 10px'}" @click="showEditTask()">编辑</button>
    <button @click="taskDeleteEvent(task.id)">删除</button>
    <!-- 写法二完 -->
  </div>
</template>

<script>
export default {
    data(){
      return{
        isShowEdit:false,
        editvalue:this.task.name
      }
    },
    props:['task','checkTask','deleteTask'],
    methods:{
       taskCheck(id){
            this.checkTask(id)
        },

        taskDelete(id){
          console.log(this.deleteTask)
          this.deleteTask(id)
        },

        showEditTask(){
          console.log('REF',this.$refs.editinput,this.$refs,this.$refs.innerHTML)
          this.isShowEdit=!this.isShowEdit
          this.editvalue=this.task.name

          //!!!!在下一次DOm更新结束后执行回调
          this.$nextTick(()=>{
            this.$refs.editinput.focus()
          })
        },

        commitEdit(id,newTask){
          this.isShowEdit=false
          this.$bus.$emit('editTaskEvent',id,newTask)
        },

        //全局事件总线实现孙传祖
        taskCheckEvent(id){
          this.$bus.$emit('checkTaskEvent',id)
        },
        taskDeleteEvent(id){
          this.$bus.$emit('deleteTaskEvent',id)
        }

    }
}
</script>

<style>

</style>