<template>
  <div>
    <!-- 子传父props写法 -->
    <!-- <input type="text" placeholder="按下回车添加任务" v-model="taskname" @keyup.enter="enterAddOneTask"/> -->
    
    <!-- 子传父自定义事件写法 -->
    <input type="text" placeholder="按下回车添加任务" v-model="taskname" @keyup.enter="enterAddOneTaskbyEvent"/>
  </div>
</template>

<script>
  import {nanoid} from 'nanoid'

  export default {
    data(){
      return{
        taskname:''
      }
    },
    props:['addOneTask'],
    methods:{
      ////!!!!!!不能与addOneTask重名
      enterAddOneTask(){
        if(this.taskname.trim()==='')
          return
        let id = nanoid()
        let task={
          id,
          'name':this.taskname,
          'completed':false
          }
        this.addOneTask(task)
      },
      enterAddOneTaskbyEvent(){
        if(this.taskname.trim()==='')
          return
        let id = nanoid()
        let task={
          id,
          'name':this.taskname,
          'completed':false
          }
        this.$emit('addOneTaskEvent',task)
        this.taskname=''
      }
    }
  }
</script>

<style>

</style>