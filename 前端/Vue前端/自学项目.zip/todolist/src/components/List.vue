<template>
  <div>
    <hr>
    <LTask v-for='task in todolist' :key='task.id' :task="task" :checkTask='checkTask' :deleteTask='deleteTask'/>
  </div>
</template>

<script>
    import LTask from './LTask.vue'

    export default {
        components:{
            LTask
        },
        data(){
            return{

            }
        },
        props:['todolist','checkTask','deleteTask'],

        methods:{
            
        },

        mounted(){
            console.log("List",this.deleteTask)
        }

    }
</script>

<style>

</style>