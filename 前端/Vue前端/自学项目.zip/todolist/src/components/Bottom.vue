<template>
  <div v-show="allnums">
    <hr>
    <div>
        <!-- <input :style="{'margin-right':'10px'}" type='checkbox' :checked='completednums==allnums' @click="allCheck"/> -->
        <!-- 更好的写法 -->
        <input :style="{'margin-right':'10px'}" type='checkbox' v-model="isAll"/>
        <span :style="{'margin-right':'10px'}">
            已完成{{completednums}}/总数{{allnums}}
        </span>
        <button @click="deleteAllCompleted">清除已完成</button>
    </div>

  </div>
</template>

<script>
export default {
    data(){
        return{}
    },
    props:['todolist','checkAll','deleteAllCompleted'],
    computed:{
        allnums(){
            return this.todolist.length
        },
        completednums(){
            return this.todolist.reduce((pre,cur)=>{
                return pre+(cur.completed?1:0)
            },0)
        },
        isAll:{
            get(){
                console.log("BottomALL")
                return this.allnums==this.completednums && this.allnums>0
            },
            set(value){
                console.log("BottomSet")
                this.betterAllCheck(value)
            }
        }
    },
    methods:{
        allCheck(event){
            console.log("CCC",event.target.checked)
            this.checkAll(event.target.checked)
        },
        betterAllCheck(value){
            this.checkAll(value)
        }
    }
}
</script>

<style>

</style>