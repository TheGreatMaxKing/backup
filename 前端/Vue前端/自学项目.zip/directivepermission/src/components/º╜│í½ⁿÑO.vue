<template>
  <div>
    <h3>partDirective</h3>
    <input type="text" v-focus placeholder="HHH" />
    <div v-htmlwow>AAA</div>
    <button
      v-update:[num]
      @click="
        () => {
          this.num++;
        }
      "
    >
      {{ num }}
    </button>
    <button @click="()=>{this.num=0}">back0</button>
    <div v-update:[num]></div>
    <div :key="num">
    <div v-param="num">Child</div>
    </div>
    <!-- <div v-update:[num]></div> -->
  </div>
</template>

<script>
export default {
  name: "partDirective",
  data() {
    return {
      num: 0,
    };
  },
  directives: {
    focus: {
      // 指令的定义
      inserted: function (el) {
        el.focus();
      },
    },
    htmlwow: {
      bind: function (el) {
        el.innerHTML = el.innerHTML + "setinnerHtml";
      },
    },
    update: {
      bind: function (el, bind) {
        console.log("bind");
        el.innerHTML = "HHHH" + bind.arg;
      },
      inserted: function (el) {
        console.log("insert");
      },
      update: function (el, bind) {
        el.innerHTML = "HHHH" + bind.arg;
        console.log("update", bind.arg);
      },
    },
    param:{
        inserted:function(el,bind){
            if(bind.value>3){
                console.log("DEL")
                el.parentNode.removeChild(el) 
            }
        },
        update:function(el,bind){
            if(bind.value>3){
                console.log("DEL",el,el.parentNode)
                el.parentNode && el.parentNode.removeChild(el)
            }
        }
    }
  },
};
</script>

<style>
</style>