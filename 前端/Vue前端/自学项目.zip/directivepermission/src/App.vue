<template>
  <div id="app">
    <part-directive></part-directive>
  </div>
</template>

<script>
import partDirective from './components/局部指令.vue'
export default {
  name: 'App',
  components: {
    partDirective
  }
}
</script>

<style>

</style>
