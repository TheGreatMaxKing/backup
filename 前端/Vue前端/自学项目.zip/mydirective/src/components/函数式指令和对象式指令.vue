<template>
<div>
  <h3>用函数式指令将值放大十倍</h3>
  <div v-big="num"></div>
  <h3>用函对象式指令获取焦点</h3>
  <input v-fbind>
  <h3>全局指令</h3>
  <input v-fbind-global>
</div>
</template>

<script>
export default {
    data(){
        return{
            num:1,
        }
    },
    //////注意事项
    // 1.命名：用横线隔开多个单词
    // 2.this:所有在Vue内的函数其this都指向vue实例，而自定义指令的this指向window
    // 
    directives:{
        ///////函数式指令被调用的时机
        // 1.指令与元素成功绑定时（并不是放入页面时）
        // 2.指令所在的模板被重新解析时
        big(element,binding){
            console.log(element,binding)
            element.innerText=binding.value*10
        },
        ///////

        //////对象式指令
        // 函数式指令相当于bind和update但不包含inserted
        fbind:{
            // 指令与元素绑定时调用（一上来就调）
            bind(element,binding){

            },
            // 指令所在的元素被插入页面时
            // 获取焦点，操作父元素等需求需要使用inserted
            inserted(element,binding){
                element.focus()
            },
            // 指令所在的模板被重新解析时
            update(element,binding){

            }
        }
    }
}
</script>

<style>

</style>