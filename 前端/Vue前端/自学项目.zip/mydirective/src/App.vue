<template>
  <div id="app">
   <funcdirective></funcdirective>
  </div>
</template>

<script>
import funcdirective from './components/函数式指令和对象式指令.vue'
export default {
  name: 'App',
  components: {
    funcdirective
  }
}
</script>

<style>

</style>
