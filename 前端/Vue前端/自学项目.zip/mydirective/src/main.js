import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

// 全局自定义指令
Vue.directive('fbind-global',{
 
  bind(element,binding){

  },
  // 指令所在的元素被插入页面时
  // 获取焦点，操作父元素等需求需要使用inserted
  inserted(element,binding){
      element.focus()
  },
  // 指令所在的模板被重新解析时
  update(element,binding){

  }
})

new Vue({
  render: h => h(App),
}).$mount('#app')
