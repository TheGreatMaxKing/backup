<template>
  <div id="app">
    <div class="redDiv">HHHH</div>
    <childstyles></childstyles>
  </div>
</template>

<script>
import childstyles from './components/childstyles.vue'

export default {
  name: 'App',
  components: {
   childstyles
  }
}
</script>

<style lang="scss">
// @import './styles/variables.scss';

.redDiv{
  // color: $red;
}
</style>
