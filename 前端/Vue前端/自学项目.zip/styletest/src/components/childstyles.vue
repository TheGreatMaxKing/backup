<template>
  <div class="childcolor">
    child
    <el-button>ELButton</el-button>
    <el-button type="primary">ELButtonPrimary</el-button>
    <button class="normalbluebutton">button</button>
    <el-menu mode="horizontal" :text-color="variables.menuText">
      <el-menu-item index="1">处理中心</el-menu-item>
      <el-menu-item index="4">订单管理</el-menu-item>
    </el-menu>
  </div>
</template>

<script>
import variables from "@/styles/variables.module.scss";
export default {
  computed: {
    variables() {
        // console.log("VVV",variables.yellow,parseInt(variables.yellow))
      return variables;
    },
  },
  mounted(){
    console.log("VVV",variables,variables.yellow,variables.red)
  }
};
</script>

<style lang="scss" scoped>
.childcolor {
  $yellow:blue;
  color: $green;
  background-color: $yellow;
}

.normalbluebutton{
  color: red!important;
  font-size: 20px;
}
</style>