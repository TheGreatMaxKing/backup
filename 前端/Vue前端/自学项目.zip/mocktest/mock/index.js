const fs = require('fs')
const path = require('path')
const JSON5 = require('json5')

const Mock = require('mockjs')

function getJSON5file(filepath) {
    var json = fs.readFileSync(path.join(__dirname, './userInfo.json5'), 'utf-8')

    var obj = JSON5.parse(json)
    
    return obj 
}

module.exports=function(app){
    app.get('/user/userinfo',function(rep,res){
        var json=getJSON5file('./userInfo.json5')
        res.json(Mock.mock(json))
    })
}