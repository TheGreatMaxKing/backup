<template>
  <div id="app">
    <div>
    <button @click="addPerson">Post传参</button>
    </div>
    <div>
    <input type="text" v-model="personid" placeholder="输入人员ID">
    <button @click="getPerson()">Get传参</button>
    </div>
    <div>
    <button @click="getpeople">自定义随机函数</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'App',

  data(){
    return{
      personid:'',
    }
  },

  components: {
  },

  methods:{
    addPerson(){
      axios({
        method: 'post',
        url:'/api/addgoods',
        data:{
          name:'Max',
          id:'999'
        }
      }).then(res=>{
        console.log("获取mock返回返回数据",res)
      },err=>{
        console.log("发送请求错误",err)
      })
    },
    getPerson(){
      axios({
        method:'get',
        url:`/api/getperson/${this.personid}`,
      }).then(res=>{
        console.log("获取mock返回返回数据",res)
      },err=>{
        console.log("发送请求错误",err)
      })
    },
    getpeople(){
       axios({
        method:'get',
        url:`/api/people`,
      }).then(res=>{
        console.log("获取mock返回返回数据",res)
      },err=>{
        console.log("发送请求错误",err)
      })
    }
  },

  mounted() {
    axios({
        url: "/api/home/get",
      }).then(res=>{
        console.log("AAA",res)
      },err=>{
        console.log("EEE",err)
      })
  },
}
</script>

<style>

</style>
