import {Random} from 'mockjs'

Random.extend({
    level: function () {
        const arr = ['PM', 'TL', 'Coordinator', 'Member']
        return this.pick(arr)
    },
    project:function(){
        const arr=['OHRP','PMIS']
        return this.pick(arr)
    }
})