import Mock from 'mockjs'



Mock.mock('/api/home/ping', function () {
    //拦截到请求后的处理逻辑
    console.log('MOCK ON')
    let obj = {
        mock: '@cword()'
    }
    return obj
})

Mock.mock('/api/home/get', 'get', {
    status: 200,
    message: "TEST",
    'data|5-10': [{
        // id:'@increment(1)',
        'id|+1': 0,
        name: '@cname()',
    }]
})

Mock.mock('/api/addgoods', 'post', function (option) {
    console.log('MOCK ON', option)
    // console.log(option)

    // return{
    //     status:200,
    //     //随机函数只能在mock对象内生效，不能在mock内的函数中生效
    //     message:'@cword(2,8)'
    // }

    //返回mock对象
    return Mock.mock({
        status: 200,
        message: '@cword(2,8)'
    })
})

Mock.mock(/\/api\/getperson/, 'get', function (option) {
    //通过正则的.exec()函数，从字符串中提取需要的数据
    const res = /\/api\/getperson\/(\d+)/.exec(option.url)

    console.log("MOCKON getperson", option, res)

    return Mock.mock({
        data: {
            id: res[1],
            name: "WWWW"
        },
        status: 200,
        message: '获取人员信息成功'
    })
})

Mock.mock('/api/people', 'get', function () {
    console.log('people Mock On')
    return Mock.mock({
        'data|5-10': [{
            // id:'@increment(1)',
            'id|+1': 0,
            name: '@cname()',
            level: "@level()",
            project:'@project'
        }],
        status: 200,
        message: '获取人员信息成功'
    })
})