<template>
  <div id="app">
    <normal-vuex></normal-vuex>
    <rocket></rocket>
  </div>
</template>

<script>
import NormalVuex from './components/NormalVuex.vue'
import rocket from './components/Rocket/rocket.vue'

export default {
  name: 'App',
  components: {
    NormalVuex,
    rocket
  }
}
</script>

<style>

</style>
