<template>
  <div>
    <div>用户名: {{ name }}</div>
    <div>权限: {{ permissions }}</div>

    <div>当前和: {{ sum }}</div>
    <div>Getterssum*2: {{ sumMul2 }}</div>
    <div>Getterssum*10: {{ sumMul10 }}</div>
    <select v-model.number="addnum">
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
    </select>
    <button @click="add(addnum)">+</button>
    <button @click="addOdd(addnum)">和为奇数才能加+</button>
    <button @click="subtract(addnum)">-</button>
    <button @click="addWait(addnum)">等两秒再加</button>
    <button @click="asyncAction">异步Action</button>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";

export default {
  data() {
    return {
      addnum: 1,
    };
  },
  computed: {
    // ////Vuex state转计算属性方法一
    // name(){
    //     return this.$store.state.name
    // },
    // id(){
    //     return this.$store.state.id
    // }
    // ////

    //
    // Vuex mapstate 写法1
    // ...mapState({name:'name',id:'id'})
    //

    // Vuex mapstate 简写
    ...mapState(["name", "permissions", "sum"]),

    //Vuex mapgetters
    ...mapGetters(["sumMul2", "sumMul10"]),
  },
  methods: {
    // add() {
    //   this.$store.dispatch("add", this.n);
    // },
    // subtract(){
    //     //直接commit略过action步骤
    //     this.$store.commit('SUBTRACT',this.n)
    // },
    asyncAction(){
        this.$store.dispatch("asyncAction",this.addnum)
    },

    //靠mapMutations生产函数
    //!!!必须在模板绑定事件时传入参数，否则会默认传入$event
    ...mapMutations({ subtract: "SUBTRACT" }),

    // addOdd() {
    //   this.$store.dispatch("addOdd", this.n);
    // },
    // addWait() {
    //   this.$store.dispatch("addWait", this.n);
    // },
    ...mapActions(['add','addOdd','addWait'])
  },
};
</script>

<style>
</style>