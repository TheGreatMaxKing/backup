<template>
  <div style="margin-top:30px">
    <div class="head"></div>
    <div style="display: flex;">
    <div class="leftwine" ></div>
    <div class="body" >
      <div class='body1' :style="{background: setFuelColor(3)}"></div>
      <div class='body1' :style="{background: setFuelColor(2)}"></div>
      <div class='body1' :style="{background: setFuelColor(1)}"></div>
      <div class='tail'></div>
    </div>
    <div class="rightwine"></div>
    </div>
    <div>
    燃料(L)：{{fuel}}
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
export default {
  data(){
    return{}
  },
  computed:{
    fuel(){
      return this.$store.state.FuelModule.fuel1
    },
    ...mapState('FuelModule',['fuel1'])
  },
  methods:{
    setFuelColor(bodyid){
      if(this.fuel>=bodyid){
        return 'rgb(191, 116, 116)'
      }
      else{
        return ''
      }
    }
  },
  mounted(){
    console.log(this.$store.state.FuelModule.fuel1)
  }
}
</script>

<style>
  .head{
    width: 0;
    height: 0;
    border-width: 0px 20px 60px 20px ;
    border-style: solid;
    border-color: rgb(255, 69, 0,0) rgb(135, 206, 235,0) rgb(0, 179, 255) rgb(154, 205, 50,0);
    margin-left: 60px;
  }

  .body{
    width:40px;
    height:120px;
    border:2px solid red;
    box-sizing: border-box;
  }

  .body1{
    width:36px;
    height:39px;
    border:1px solid red;
    box-sizing: border-box;
  }

  .leftwine{
    margin-top: 20px;
    width: 0;
    height: 0;
    border-width: 80px 30px 20px 30px ;
    border-style: solid;
    border-color: rgb(255, 69, 0,0) rgb(135, 206, 235,1) rgb(0, 179, 255,0) rgb(154, 205, 50,0)
  }

  .rightwine{
    margin-top: 20px;
    width: 0;
    height: 0;
    border-width: 80px 30px 20px 30px ;
    border-style: solid;
    border-color: rgb(255, 69, 0,0) rgb(135, 206, 235,0) rgb(0, 179, 255,0) rgb(135, 206, 235,1)
  }

  .tail{
    width:36px;
    height:3px;
    border:1px solid red;
    box-sizing: border-box;
  }
</style>