<template>
  <div>
    <button @click="addFuel1()">添加燃料</button>
    <button @click="addMaxFuel()">加三格燃料</button>
    <button @click="addFuelUntilMax()">加满燃料</button>
    <button @click="releaseFuel(1)">释放燃料</button>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
export default {
  data(){
    return{

    }
  },
  methods:{
    ...mapActions('FuelModule',{'addMaxFuel':'addMaxFuel','addFuelUntilMax':'addFuelUntilMax','releaseFuel':'releaseFuel'}),
    
    ...mapMutations('FuelModule',{'decrement':'REDUCEFULE1'}),

    addFuel1(){
      this.$store.dispatch('FuelModule/addFuel1',1)
    }
  }
}
</script>

<style>

</style>