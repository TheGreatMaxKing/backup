<template>
  <div>
    <rocket></rocket>
    <hr>
    <rocket-controller></rocket-controller>
  </div>
</template>

<script>
import rocket from './rocketComponents/rocketBody.vue'
import rocketController from './rocketComponents/rocketController.vue'
export default {
    components:{
        rocket,
        rocketController
    }
}
</script>

<style>

</style>