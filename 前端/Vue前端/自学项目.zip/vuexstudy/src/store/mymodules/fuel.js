//自定义模块
const FuelModule={
    namespaced:true,
    state:{
      fuel1:0,
      maxfuel1:3, 
    },
    actions:{
      addFuel1(context,value){
        let fuel1=context.state.fuel1
        let maxfuel1=context.state.maxfuel1
        if(fuel1<maxfuel1){
            console.log("FFFF",value)
            if(fuel1+value<=maxfuel1){
                context.commit('ADDFUEL1',value)
            }
            else{
                context.commit('ADDFUEL1',maxfuel1-fuel1)
                alert('燃料已加满')
            }
        }
      },
      releaseFuel(context,value){
        let fuel1=context.state.fuel1
        if(fuel1>0){
            console.log("FFFF",value)
            if(fuel1-value>0){
                context.commit('REDUCEFULE1',value)
            }
            else{
                context.commit('REDUCEFULE1',fuel1)
            }
        }
      },
      async addMaxFuel(context){
        let fuel1=context.state.fuel1
        let maxfuel1=context.state.maxfuel1
        for(let i=fuel1;i<maxfuel1;i++){
            let p1=new Promise((resolve)=>{
                setTimeout(()=>{
                    context.dispatch('addFuel1',1)
                    resolve()
                },1000)
            })
            await p1
        }
      },
      async addFuelUntilMax(context){
        // let fuel1=context.state.fuel1
        let maxfuel1=context.state.maxfuel1
        while(context.state.fuel1<maxfuel1){
            let p1=new Promise((resolve)=>{
                setTimeout(()=>{
                    context.dispatch('addFuel1',1)
                    resolve()
                },1000)
            })
            await p1
        }
      }  

    },
    mutations:{
        ADDFUEL1(state,value){
            console.log("AF",value)
            state.fuel1+=value
        },
        REDUCEFULE1(state,value){
            console.log("AF",value)
            state.fuel1-=value
        }
    },
    getters:{
        fuel1space(state){
            return state.maxfuel1-state.fuel1
        }
    }

}

export default FuelModule