import {repository} from '@loopback/repository';
import {get, getModelSchemaRef} from '@loopback/rest';
import {LinlinTest} from './../models/linlin-test.model';
import {Return} from './../models/return.model';
import {LinlinTestRepository} from './../repositories/linlin-test.repository';


export class LinlinTestController {
  constructor(
    @repository(LinlinTestRepository)
    public linlinTestRepository: LinlinTestRepository,
  ) { }
  /**获取table数据
    * @param site
    * @param plant
    * @param line
    * @param username
    * @return 返回给前端处理好的去重数据
    */
  @get('/linlin-test/gettable', {
    responses: {
      '200': {
        description: '',
        content: {
          'application/json': {
            schema: getModelSchemaRef(LinlinTest),
          },
        },
      },
    },
  })
  async gettable(
    // @param.path.string('site') site: string,
    // @param.path.string('plant') plant: string,
    // @param.query.string('line') line: string,
  ): Promise<Return> {
    const result = new Return();
    result.statusCode = 200;
    result.message = '';
    result.data = {};
    let tabledata;
    let sql;
    try {

      sql = `SELECT * FROM linlin.linlin_test`
      tabledata = await this.linlinTestRepository.dataSource.execute(sql);
      result.message = 'success';
      result.data = tabledata
      console.log(result.data);
    } catch (error) {
      result.statusCode = 500;
      result.message = `error: ${error}`;
    }
    return result;
  }




}
