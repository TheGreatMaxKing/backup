import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {PgsqlDataSource} from '../datasources';
import {LinlinTest, LinlinTestRelations} from '../models';

export class LinlinTestRepository extends DefaultCrudRepository<
  LinlinTest,
  typeof LinlinTest.prototype.id,
  LinlinTestRelations
> {
  constructor(
    @inject('datasources.pgsql') dataSource: PgsqlDataSource,
  ) {
    super(LinlinTest, dataSource);
  }
}
