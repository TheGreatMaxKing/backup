import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {idInjection: false, postgresql: {schema: 'linlin', table: 'linlin_test'}}
})
export class LinlinTest extends Entity {

  @property({
    type: 'number',
    required: false,
    scale: 0,
    id: 1,
    postgresql: {columnName: 'station_id', dataType: 'integer', dataLength: null, dataPrecision: null, dataScale: 0, nullable: 'NO'},
  })
  station_id: number;

  @property({
    type: 'string',
    postgresql: {columnName: 'site', dataType: 'character varying', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'YES'},
  })
  site?: string;

  @property({
    type: 'string',
    postgresql: {columnName: 'plant', dataType: 'character varying', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'YES'},
  })
  plant?: string;

  @property({
    type: 'string',
    postgresql: {columnName: 'line', dataType: 'character varying', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'YES'},
  })
  line?: string;

  @property({
    type: 'string',
    postgresql: {columnName: 'model', dataType: 'character varying', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'YES'},
  })
  model?: string;

  @property({
    type: 'string',
    postgresql: {columnName: 'station', dataType: 'character varying', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'YES'},
  })
  station?: string;

  @property({
    type: 'number',
    scale: 0,
    postgresql: {columnName: 'updatetime', dataType: 'bigint', dataLength: null, dataPrecision: null, dataScale: 0, nullable: 'YES'},
  })
  updatetime?: number;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<LinlinTest>) {
    super(data);
  }
}

export interface LinlinTestRelations {
  // describe navigational properties here
}

export type LinlinTestWithRelations = LinlinTest & LinlinTestRelations;
