
/*
 * @Author: your name
 * @Date: 2021-02-27 16:32:18
 * @LastEditTime: 2021-02-27 16:34:13
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \mmdc-api\src\models\return.model.ts
 */
import {Entity, model, property} from '@loopback/repository';

@model()
export class Return extends Entity {
  @property({
    type: 'number',
  })
  statusCode?: number;

  @property({
    type: 'string',
  })
  message?: string;

  @property({
    type: 'number',
  })
  nums?: number;

  @property({
    type: 'object',
  })
  data?: object;

  @property({
    type: 'number',
  })
  status?: number;

  @property({
    type: 'number',
  })
  rate?: number;

  constructor(data?: Partial<Return>) {
    super(data);
  }
}

export interface ReturnRelations {
  // describe navigational properties here
}

export type ReturnWithRelations = Return & ReturnRelations;
