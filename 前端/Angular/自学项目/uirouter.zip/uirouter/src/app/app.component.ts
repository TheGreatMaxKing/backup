import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // styleUrls: ['./app.component.css'],
  styles:[".active { font-weight: bold } a + a { margin-left: .5em; }"]
})
export class AppComponent {
  title = 'uirouter';
}
