import { HelloComponent } from "../components/hello/hello.component";
import { PeopleComponent } from "../components/people/people.component";
import { AboutComponent } from "../components/about/about.component";
import { PersonComponent } from "../components/person/person.component";
import { PeopleService } from "../services/people.service";

import { Transition } from "@uirouter/core";

/** States */
export const helloState = { name: "hello1", url: "/hello1", component: HelloComponent };

export const aboutState = { name: "about", url: "/about", component: AboutComponent };

export const peopleState = {
  name: "people",
  url: "/people1",
  component: PeopleComponent,
  resolve: [
    {
      token: "peopletoken",
      deps: [PeopleService],
      resolveFn: (peopleService: PeopleService) => peopleService.getAllPeople()
    }
  ]
};

//单路由
// export const personState = {
//   name: "person",
//   url: "/people/:personId",
//   component: PersonComponent,
//   resolve: [
//     {
//       token: "person",
//       deps: [Transition, PeopleService],
//       resolveFn: (trans: Transition, peopleService: PeopleService) =>
//         peopleService.getPerson(trans.params()["personId"])
//     }
//   ]
// };

//子路由
export const personState = {
  name: "people.person1",
  url: "/:personId",
  component: PersonComponent,
  resolve: [
    {
      token: "person",
      deps: [Transition, 'peopletoken'],
      resolveFn: (trans: Transition, people: any[]) => 
          people.find(person => person.id === trans.params()["personId"])
    }
  ]
};