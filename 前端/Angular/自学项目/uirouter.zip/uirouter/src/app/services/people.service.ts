import { Injectable ,Inject} from '@angular/core';
import{HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class PeopleService {

  constructor(@Inject(HttpClient) public http: HttpClient) {
    console.log("PeopleService constructor");
  }

  getAllPeople() {
    // console.log("HHHHH",this.http.get<any[]>("/assets/people.json"))
    let promisetest=new Promise((resolve,reject)=>{
     
          resolve([
            {
              "id": "293",
              "isActive": false,
              "eyeColor": "brown",
              "name": "Ingrid Townsend",
              "company": "JASPER",
              "email": "ingridtownsend@jasper.com",
              "address": "690 Charles Place, Santel, Northern Mariana Islands, 3791"
            },
            {
              "id": "581",
              "isActive": true,
              "eyeColor": "blue",
              "name": "Estrada Nolan",
              "company": "FIBRODYNE",
              "email": "estradanolan@fibrodyne.com",
              "address": "317 Seeley Street, Cade, Maryland, 3976"
            },
            {
              "id": "29",
              "isActive": true,
              "eyeColor": "brown",
              "name": "Laverne Andrews",
              "company": "INTRAWEAR",
              "email": "laverneandrews@intrawear.com",
              "address": "760 Provost Street, Valle, Alaska, 4628"
            },
            {
              "id": "856",
              "isActive": false,
              "eyeColor": "green",
              "name": "Hull Woodward",
              "company": "SENMAO",
              "email": "hullwoodward@senmao.com",
              "address": "452 Union Avenue, Hachita, Palau, 9166"
            },
            {
              "id": "2321",
              "isActive": false,
              "eyeColor": "green",
              "name": "Maria Stanley",
              "company": "EYERIS",
              "email": "mariastanley@eyeris.com",
              "address": "350 Remsen Avenue, Abrams, Ohio, 6355"
            }
          ])

  })
    return promisetest
  }

  getPerson(id:any) {
    function personMatchesParam(person:any) {
      return person.id === id;
    }

    return this.getAllPeople().then((people:any) => people.find(personMatchesParam));
  }
}
