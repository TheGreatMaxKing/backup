import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { UIRouterModule } from '@uirouter/angular';

import { HttpClientModule } from '@angular/common/http';

import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import { HelloComponent } from './components/hello/hello.component';
import { AboutComponent } from './components/about/about.component';
import { PeopleComponent } from './components/people/people.component';
import { PersonComponent } from './components/person/person.component';

import { helloState, aboutState, peopleState, personState } from "./config/states";
import { uiRouterConfigFn } from './config/router.config';

const INITIAL_STATES = [helloState, aboutState, peopleState, personState];

// const helloState = { name: "hello1", url: "/hello", component: HelloComponent };
// const aboutState = { name: "about", url: "/about", component: AboutComponent };

@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    AboutComponent,
    PeopleComponent,
    PersonComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    UIRouterModule.forRoot({ 
      states: INITIAL_STATES, 
      useHash: true,
      config:uiRouterConfigFn
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

// platformBrowserDynamic().bootstrapModule(AppModule).then(ref => {
//   // Ensure Angular destroys itself on stackblitz hot reloads.
//   if ((window as any)['ngRef']) {
//     (window as any)['ngRef'].destroy();
//   }
//   (window as any)['ngRef'] = ref;

//   // Otherwise, log the boot error
// }).catch(err => console.error(err));
