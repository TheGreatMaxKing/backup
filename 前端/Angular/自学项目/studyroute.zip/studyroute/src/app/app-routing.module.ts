import { NewsinfoComponent } from './components/newsinfo/newsinfo.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//引入组件
import { HomeComponent } from './components/home/home.component';
import { NewsComponent } from './components/news/news.component';
import { UserComponent } from './components/user/user.component';

//配置路由
const routes: Routes = [
  {
    path:'home',
    component:HomeComponent,
    children:[
      {
        path:'child1',
        component:NewsinfoComponent,
      }
    ]
  },
  {
    path:'news',
    component:NewsComponent
  },
  {
    path:'newInfo/:nid',
    component:NewsinfoComponent
  },
  {
    path:'user',
    component:UserComponent
  },
  //默认路由
  {
    path:'',
    redirectTo:'home',
    pathMatch:"full"
  },
  //匹配不到路由时加载的组件
  {
    //匹配任意路由
    path:'**',
    component:HomeComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
