import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-newsinfo',
  templateUrl: './newsinfo.component.html',
  styleUrls: ['./newsinfo.component.css']
})
export class NewsinfoComponent implements OnInit {

  constructor(private route:ActivatedRoute) { }

  ngOnInit(): void {
    //获取动态路由
    console.log("NF",this.route.params)

    //获取路由参数
    this.route.params.subscribe((data)=>{
      console.log(data["nid"])
    })

  }

}
