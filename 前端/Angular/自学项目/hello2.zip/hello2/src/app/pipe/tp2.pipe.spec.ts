import { Tp2Pipe } from './tp2.pipe';

describe('Tp2Pipe', () => {
  it('create an instance', () => {
    const pipe = new Tp2Pipe();
    expect(pipe).toBeTruthy();
  });
});
