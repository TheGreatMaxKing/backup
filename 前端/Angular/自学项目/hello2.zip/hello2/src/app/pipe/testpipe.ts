import { Pipe } from "@angular/core";

@Pipe({
    name:'testpipe'
})
export class TestPipe{
    //管道执行过滤任务的固定默认函数
    transform(val:any,param1="HHH"){
        if(val==1){
            return "P1"+param1
        }else if(val==2){
            return "P2"+param1
        }else{
            return "PP"+param1
        }
    }
}