import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tp2'
})
export class Tp2Pipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
