import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  constructor() { }

  setItem(key:any,value:any){
    localStorage.setItem(key,JSON.stringify(value))
  }

  getItem(key:any){
    let keyJson=localStorage.getItem(key)
    if(typeof keyJson=='string'){
      return JSON.parse(keyJson)
    }
    else return JSON.parse("{}")
  }

  removeItem(key:any){
    localStorage.removeItem(key)
  }
}
