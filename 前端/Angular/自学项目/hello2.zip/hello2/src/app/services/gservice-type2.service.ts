import { Injectable } from '@angular/core';

@Injectable()
export class GserviceType2Service {

  constructor() { }

  gs2(){
    console.log("S2")
  }
}
