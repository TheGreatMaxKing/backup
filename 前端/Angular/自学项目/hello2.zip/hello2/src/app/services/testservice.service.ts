import { Injectable } from '@angular/core';

//所有服务都是可被注入的
@Injectable({
  providedIn: 'root'//指定当前的服务对象在“根模块（appmodule默认提供者）”中提供
})
export class TestserviceService {


  count=0

  constructor() { }

  test(){
    return "TestServiceOK";
  }

  addOne(){
    this.count=this.count+1
  }
}
