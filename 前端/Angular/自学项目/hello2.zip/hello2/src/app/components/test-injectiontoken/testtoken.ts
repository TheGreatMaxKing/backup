import { InjectionToken } from '@angular/core';

interface Column {
    columnId:string;
    columnName: string;
    width: number
}

export const COLUMN_TOKEN = new InjectionToken<Column[]>('column.config');

export const COLUMN:Array<Column> = [
    {
        columnId: 'aeId',
        columnName: 'AE ID',
        width: 10
    },
    {
        columnId: 'aeName',
        columnName: 'AE Name',
        width: 10
    },
    {
        columnId: 'aeStatus',
        columnName: 'AE Status',
        width: 8
    },
    {
        columnId: 'geographyName',
        columnName: 'Geography',
        width: 10
    },
    {
        columnId: 'aeBusinessName',
        columnName: 'Business',
        width: 12
    },
    {
        columnId: 'reviewNumber',
        columnName: 'CA Review Coverage',
        width: 10
    },
    {
        columnId: 'assessmentId',
        columnName: 'Assessment ID',
        width: 10
    },
    {
        columnId: 'assessmentDate',
        columnName: 'Assessment Rating Date',
        width: 10
    },
    {
        columnId: 'overallResidualRating',
        columnName: 'Overall Residual Rating',
        width: 10
    },
    {
        columnId: 'selectedRiskTaxonomy',
        columnName: 'Risk Taxonomy by Level',
        width: 10
    },
    {
        columnId: 'selectedRiskTaxonomyRating',
        columnName: 'Selected Risk Taxonomy Rating',
        width: 10
    }
];