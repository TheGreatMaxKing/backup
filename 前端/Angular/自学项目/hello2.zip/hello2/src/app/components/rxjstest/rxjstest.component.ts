import { Component, OnInit } from '@angular/core';
import { RxjsserviceService } from './rxjsservice.service';

//rxjs提供的工具方法
import {map,filter} from 'rxjs/operators';

@Component({
  selector: 'app-rxjstest',
  templateUrl: './rxjstest.component.html',
  styleUrls: ['./rxjstest.component.css']
})
export class RxjstestComponent implements OnInit {

  constructor(private rxjsService:RxjsserviceService) { }

  ngOnInit(): void {
    this.rxjsService.getCallBack((data:any)=>{console.log(data)})
    this.rxjsService.getPromise().then((data)=>{
      console.log(data)
    })
    
    //获取RXJS数据
    var rxjsData=this.rxjsService.getRxjs();
    rxjsData.subscribe((data)=>{
      console.log(data)
    })

    //RXJS取消订阅
    var streem=this.rxjsService.getRxjs();
    var d=streem.subscribe((data)=>{
      console.log(data)
    })

    setTimeout(()=>{
      d.unsubscribe()
    },1000)

    //RXJS多次执行Interval
    // var rxjsIntervalData=this.rxjsService.getRxjsInterval();
    // rxjsIntervalData.subscribe((data)=>{
    //   console.log(data)
    // })

    //RXjs过滤器(Pipe)
    var streemNum=this.rxjsService.getRxjsInterval();
    streemNum.pipe(
      filter((data)=>{
        return data%2==0
      }),
      map((data)=>{
        return data*data
      })
    )
    .subscribe((data)=>{
      console.log(data)
    })
  }

}
