import { Component, OnInit } from '@angular/core';
import { Http,Jsonp } from '@angular/http';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  public courses:any
  name:any
  password:any

  constructor(private http:Http,private jsonp:Jsonp,private httpclient:HttpClient) { }

  courseUrl='http://10.62.148.43:3001/course'
  nameUrl='http://10.62.148.43:3001/login'

  ngOnInit(): void {
  }

  //HttpClient
  requestData():any{
    let that=this
    // console.log(this.httpclient.get(this.courseUrl))
    this.httpclient.get(this.courseUrl).subscribe((response)=>{
      this.courses=response
      console.log(response)
    })

  }
  postName(user:any,password:any){
    let that=this
    this.httpclient.post(that.nameUrl,{user,password}).subscribe(
      (res)=>{
        console.log(res)
      },
      (err)=>{
        console.log(err)
      }
    )
  }

  ////Http
  // requestData():void{
  //   let that=this
  //   this.http.get(this.courseUrl).subscribe(
  //     function(data:any){
  //       let courselist=JSON.parse(data['_body'])
  //       console.log(courselist)
  //       that.courses=courselist
  //     },
  //     function(err){
  //       console.log(err)
  //     }
  //   )

  // }
  // postName(user:any,password:any){
  //   let that=this
  //   this.http.post(that.nameUrl,{user,password}).subscribe(
  //     (res)=>{
  //       console.log(res)
  //     },
  //     (err)=>{
  //       console.log(err)
  //     }
  //   )
  // }

}
