import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bindfunc',
  templateUrl: './bindfunc.component.html',
  styleUrls: ['./bindfunc.component.css']
})
export class BindfuncComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  testClick(){
    console.log("Click")
  }
  testDbClick(){
    console.log("DbClick")
  }

}
