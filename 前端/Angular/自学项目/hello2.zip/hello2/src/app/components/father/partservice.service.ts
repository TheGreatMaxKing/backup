import { Injectable } from '@angular/core';

@Injectable()
export class PartserviceService {
  count=0
  constructor() { }

  addone(){
    this.count=this.count+1;
  }
}
