import { Injectable } from '@angular/core';
import { observable, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RxjsserviceService {

  constructor() { }

  //同步
  getData(){
    return "T"
  }

  //callBack
  getCallBack(func:any){
    setTimeout(()=>{
      func("callBackD")
    },1000)
  }

  //promise
  getPromise(){
    let pm=new Promise((res,rej)=>{
      setTimeout(()=>{
        res("PromiseData")
      },1000)
    })

    return pm
  }

  //rxjs
  getRxjs(){
    let OB=new Observable<any>((observer)=>{
      setTimeout(()=>{
        let data="RxjsData"
        observer.next(data)
        // observer.error("EEEEE")
      },3000)
    })

    return OB
  }

  //rxjs多次执行(Promise无此能力)
  getRxjsInterval(){
    return new Observable<any>((observer)=>{
      let count=1
      setInterval(()=>{
        var data="RxjsInterval"
        observer.next(count)
        count++;
      },3000)
    })
  }

}
