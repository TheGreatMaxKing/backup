import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {

  tp=1

  st="FFFFFF"

  obj={
    "HHH":{
      "YYY":5,
      "qq":10
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

}
