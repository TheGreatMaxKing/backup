import { Component, Inject, OnInit } from '@angular/core';

import { COLUMN_TOKEN,COLUMN } from './testtoken';

@Component({
  selector: 'app-test-injectiontoken',
  templateUrl: './test-injectiontoken.component.html',
  styleUrls: ['./test-injectiontoken.component.css'],
  providers:[{
    provide:COLUMN_TOKEN,
    useValue:COLUMN
  }]
})
export class TestInjectiontokenComponent implements OnInit {

  constructor(@Inject(COLUMN_TOKEN) public columns:any) { }

  ngOnInit(): void {
    console.log("TOKEN",this.columns)
  }

}
