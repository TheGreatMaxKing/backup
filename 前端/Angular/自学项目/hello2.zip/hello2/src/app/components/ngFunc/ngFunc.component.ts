import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngFunc',
  templateUrl: './ngFunc.component.html',
  styleUrls: ['./ngFunc.component.css']
})
export class ngFuncComponent implements OnInit {

  title:string=''
  id=1
  innerHtml=""
  list=[1,2,3,4,5,6]
  ngf=false
  switchtype="typeA1"
  constructor() {
    this.title="NNNN"
    this.innerHtml="<h2>InnerHtml</h2>"
   }

  ngOnInit(): void {
  }

}
