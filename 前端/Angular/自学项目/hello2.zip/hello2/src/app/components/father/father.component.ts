import { Component, OnInit ,ViewChild} from '@angular/core';
import { GserviceType2Service } from 'src/app/services/gservice-type2.service';
import { TestserviceService } from 'src/app/services/testservice.service';

@Component({
  selector: 'app-father',
  templateUrl: './father.component.html',
  styleUrls: ['./father.component.css']
})
export class FatherComponent implements OnInit {

  @ViewChild('son') ViewSon:any;

  fathermsg="Call Daddy"

  public Sonvalue:any=1

  constructor(private testService:TestserviceService,
    private gservice2:GserviceType2Service
    ) { }

  ngOnInit(): void {
    //console.log("V",this.ViewSon)
    const testserviceResult=this.testService.test()
    console.log("SSSSS",testserviceResult);
    this.gservice2.gs2()
  }

  getSonMsg(value:string){
    alert(value)
    this.Sonvalue=value
    console.log("VVV",this.ViewSon.sonvalue)
  }

  fatherfunc(sonvalue:any){
    alert(sonvalue+ String(this.Sonvalue))
    this.Sonvalue=sonvalue
    console.log(this.Sonvalue)
  }

}
