import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binddata',
  templateUrl: './binddata.component.html',
  styleUrls: ['./binddata.component.css']
})
export class BinddataComponent implements OnInit {

  tsTohtml=0
  picsrc="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.jj20.com%2Fup%2Fallimg%2Ftp09%2F210F2130512J47-0-lp.jpg&refer=http%3A%2F%2Fimg.jj20.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1662881923&t=e40840ca73b4dfd5244d45d78c744e7c"

  user=""
  constructor() { }

  ngOnInit(): void {
  }

}
