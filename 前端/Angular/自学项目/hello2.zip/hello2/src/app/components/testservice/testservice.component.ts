import { StorageService } from './../../services/storage.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testservice',
  templateUrl: './testservice.component.html',
  styleUrls: ['./testservice.component.css']
})
export class TestserviceComponent implements OnInit {

  middleuser=""
  user=""



  /////引入服务方法1（不推荐）
  // public teststorageservice=new StorageService()

  // constructor() {
  //   console.log(this.teststorageservice)
  //   this.teststorageservice.setItem('username',"MaxWell")
  // }
  ///

  ////引入服务方法2 依赖注入
  constructor(private storage:StorageService){
      console.log(this.storage)
      this.user=storage.getItem("username")
  }

  ngOnInit(): void {
  }

  setname(user:string){
    this.user=user
    this.storage.setItem('username',user)
    alert("设置用户"+user)
  }

}
