import { Component, OnInit } from '@angular/core';
import { TestserviceService } from 'src/app/services/testservice.service';
import { PartserviceService } from '../partservice.service';

@Component({
  selector: 'app-son2',
  templateUrl: './son2.component.html',
  styleUrls: ['./son2.component.css'],
  providers:[PartserviceService]
})
export class Son2Component implements OnInit {

  son2value=0

  count=0

  countg=0

  constructor(private partS:PartserviceService,
    private gS:TestserviceService) { 
  }

  ngOnInit(): void {
  }

  sendSon2ToSon1ByService(){
    this.son2value=this.son2value+1
  }


  partServiceAddOne(){
    this.partS.addone();
    this.count=this.partS.count
  }


  gserviceAddOne(){
    this.gS.addOne()
    this.countg=this.gS.count;
  }



}
