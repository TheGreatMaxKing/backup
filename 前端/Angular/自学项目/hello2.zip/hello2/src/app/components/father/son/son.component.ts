import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { TestserviceService } from 'src/app/services/testservice.service';
import { PartserviceService } from '../partservice.service';

@Component({
  selector: 'app-son',
  templateUrl: './son.component.html',
  styleUrls: ['./son.component.css'],
  providers:[PartserviceService]
})
export class SonComponent implements OnInit {

  count=0

  countg=0

  @Input() msg:string=''
  @Input() fatherfunc:any

  @Input() sonvalue="HHH"

  @Output() sendToFather:EventEmitter<string>=new EventEmitter<string>()

  constructor(private partS:PartserviceService,private gS:TestserviceService) {

   }

  ngOnInit(): void {
  }

  sendMsg=()=>{
    this.sendToFather.emit('I am your son')
  }

  sonFunc=(value:any)=>{
    console.log("sonFunc",value)
  }

  partSAddone(){
    this.partS.addone();
    this.count=this.partS.count
  }

  gserviceAddOne(){
    this.gS.addOne()
    this.countg=this.gS.count;
  }


}
