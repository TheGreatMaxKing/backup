import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { ngFuncComponent } from './components/ngFunc/ngFunc.component';
import { BinddataComponent } from './components/binddata/binddata.component';
import { FormsModule } from '@angular/forms';
import { BindfuncComponent } from './components/bindfunc/bindfunc.component';
import { StorageService } from './services/storage.service';
import { TestserviceComponent } from './components/testservice/testservice.component';
import { NewsComponent } from './components/news/news.component';
import {HttpModule,JsonpModule} from '@angular/http'
import {HttpClientModule} from '@angular/common/http';
import { FatherComponent } from './components/father/father.component';
import { SonComponent } from './components/father/son/son.component';
import { Son2Component } from './components/father/son2/son2.component'
import { SendDataService } from './sevices/send-data.service';
import { PipeComponent } from './components/pipecomponet/pipe/pipe.component';
import { TestPipe } from './pipe/testpipe';
import { Tp2Pipe } from './pipe/tp2.pipe';
import { GserviceType2Service } from './services/gservice-type2.service';
import { RxjstestComponent } from './components/rxjstest/rxjstest.component';
import { TestInjectiontokenComponent } from './components/test-injectiontoken/test-injectiontoken.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ngFuncComponent,
    BinddataComponent,
    BindfuncComponent,
    TestserviceComponent,
    NewsComponent,
    FatherComponent,
    SonComponent,
    Son2Component,
    PipeComponent,
    TestPipe,
    Tp2Pipe,
    RxjstestComponent,
    TestInjectiontokenComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    HttpModule,
    JsonpModule,
  ],
  //引入服务
  providers: [StorageService,SendDataService,GserviceType2Service],
  bootstrap: [AppComponent]
})
export class AppModule { }
